WordPress Media Javascript Guide
==============================

Enabling this WordPress plugin will create a top-level admin page "Media Guide," where you'll find documentation on Javascript design patterns and reusable elements from the media experience.

![A screenshot of the plugin](/screenshot.png?raw=true "Example of documentation")