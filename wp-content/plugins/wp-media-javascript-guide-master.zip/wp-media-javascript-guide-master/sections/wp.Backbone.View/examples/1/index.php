<div class="view-1-container"></div>
<button class="js--render-view-1">Click to render the parent view</button>
<script type="text/template" id="tmpl-view-1">
	A view template.
	<div class="subview-container"></div>
</script>
<script type="text/template" id="tmpl-view-2">
	A subview template.
</script>