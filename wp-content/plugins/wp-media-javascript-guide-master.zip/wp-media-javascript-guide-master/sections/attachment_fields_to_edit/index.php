<h3>attachment_fields_to_edit</h3>
<p>A filter that allows for developers to add custom UI elements to an attachment details view.</p>
<p>See the <a href="http://codex.wordpress.org/Plugin_API/Filter_Reference/attachment_fields_to_edit">codex page</a>.</p>