<button class="js--switch-to-on-state">Switch to "on" state</button>
<button class="js--switch-to-off-state">Switch to "off" state</button>