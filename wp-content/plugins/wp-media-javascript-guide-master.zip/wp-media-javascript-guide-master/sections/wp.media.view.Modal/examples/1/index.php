<button class="js--open-media-modal">Open a modal</button>
<script type="text/template" id="tmpl-modal-content">
	<h1>Hi, I&#39;m a Modal!</h1>
</script>