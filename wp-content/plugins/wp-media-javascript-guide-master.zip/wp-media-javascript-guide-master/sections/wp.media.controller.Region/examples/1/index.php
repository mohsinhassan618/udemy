<script type="text/template" id="tmpl-view-1">
	<h1>Hi, I&#39;m a view inside a region!</h1>
</script>
<div class="region-parent-view">
	<div class="region-1"></div>
</div>
<button class="js--render-region">Render a view inside a region</button>