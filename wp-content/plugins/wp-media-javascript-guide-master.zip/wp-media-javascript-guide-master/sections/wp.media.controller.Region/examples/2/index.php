<script type="text/template" id="tmpl-view-1">
	<h1>Hi, I&#39;m a view inside a region in "a" mode!</h1>
</script>
<script type="text/template" id="tmpl-view-2">
	<h1>Hi, I&#39;m a view inside a region in "b" mode!</h1>
</script>
<div class="region-parent-view">
	<div class="region-1"></div>
</div>
<button class="js--switch-region-to-a-mode">Switch the region to "a" mode</button>
<button class="js--switch-region-to-b-mode">Render the region in "b" mode</button>